package com.phonegap.api.impl;

public class FileCommand {
}
